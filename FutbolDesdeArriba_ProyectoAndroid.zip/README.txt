FÚTBOL DESDE ARRIBA - PROTOTIPO ANDROID

Qué incluye:
- Juego en orientación horizontal y vista desde arriba.
- Control táctil tipo joystick en el lado izquierdo.
- Botón TIRO en el lado derecho.
- Balón con movimiento y rebotes.
- Rival controlado por una IA sencilla que persigue el balón.
- Marcador y goles.

IMPORTANTE:
Este ZIP contiene el PROYECTO FUENTE de Android Studio, no un APK ya compilado.
No puedo compilar ni probar un APK Android firmado desde este entorno.

Cómo generar el APK:
1. Instala Android Studio en un PC.
2. Descomprime este ZIP.
3. Abre la carpeta FutbolDesdeArriba en Android Studio.
4. Espera a que termine la sincronización de Gradle.
5. Si Android Studio pide instalar Android SDK 35, acepta.
6. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio generará el APK en app/build/outputs/apk/debug/.

Para instalarlo:
- Copia app-debug.apk a tu Android y ábrelo.
- Si Android lo solicita, permite instalar aplicaciones desde esa fuente.

Controles:
- Mantén y arrastra en la zona inferior izquierda para moverte.
- Toca la zona inferior derecha (TIRO) cuando estés cerca del balón.
- El objetivo es llevar el balón hacia el arco de la derecha.
