package com.example.futboldesdearriba

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(FootballView())
    }
}

private class FootballView : View() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var w = 0f
    private var h = 0f
    private var px = 0f
    private var py = 0f
    private var ex = 0f
    private var ey = 0f
    private var bx = 0f
    private var by = 0f
    private var bvx = 0f
    private var bvy = 0f
    private var joyX = 0f
    private var joyY = 0f
    private var joyActive = false
    private var shootPressed = false
    private var score = 0
    private var message = "¡Marca un gol!"
    private var lastTime = 0L
    private val playerR = 23f
    private val ballR = 11f

    private fun color(c: Int) { p.color = c; p.style = Paint.Style.FILL }
    private fun circle(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        color(col); c.drawCircle(x, y, r, p)
    }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int = Color.WHITE) {
        color(col); p.textSize = size; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(s, x, y, p)
    }

    override fun onSizeChanged(width: Int, height: Int, oldw: Int, oldh: Int) {
        w = width.toFloat(); h = height.toFloat()
        resetPositions()
    }

    private fun resetPositions() {
        px = w * .27f; py = h * .5f
        ex = w * .72f; ey = h * .5f
        bx = w * .5f; by = h * .5f
        bvx = 0f; bvy = 0f
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (w <= 0f || h <= 0f) return
        val now = System.nanoTime()
        val dt = if (lastTime == 0L) 0.016f else ((now-lastTime)/1e9).toFloat().coerceIn(0f,.04f)
        lastTime = now
        update(dt)

        // Grass and pitch
        color(Color.rgb(35, 135, 72)); c.drawRect(0f,0f,w,h,p)
        color(Color.rgb(42, 150, 80)); c.drawRect(0f,h*.08f,w,h*.92f,p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.WHITE
        c.drawRect(w*.06f,h*.12f,w*.94f,h*.88f,p)
        c.drawLine(w*.5f,h*.12f,w*.5f,h*.88f,p)
        c.drawCircle(w*.5f,h*.5f,h*.13f,p)
        c.drawRect(w*.06f,h*.31f,w*.19f,h*.69f,p)
        c.drawRect(w*.81f,h*.31f,w*.94f,h*.69f,p)
        p.style = Paint.Style.FILL
        // Goals
        color(Color.WHITE); c.drawRect(w*.015f,h*.40f,w*.06f,h*.60f,p)
        c.drawRect(w*.94f,h*.40f,w*.985f,h*.60f,p)

        // Ball shadow, players, ball
        circle(c,px+3,py+5,playerR,Color.argb(55,0,0,0))
        circle(c,ex+3,ey+5,playerR,Color.argb(55,0,0,0))
        circle(c,px,py,playerR,Color.rgb(35,95,230))
        circle(c,ex,ey,playerR,Color.rgb(220,55,55))
        circle(c,bx,by,ballR,Color.WHITE)
        color(Color.BLACK); c.drawCircle(bx,by,ballR,p.apply { style=Paint.Style.STROKE; strokeWidth=2f }); p.style=Paint.Style.FILL
        text(c,"TÚ",px-13,py+5,13f)
        text(c,"CPU",ex-17,ey+5,12f)

        // Score
        color(Color.argb(170,0,0,0)); c.drawRoundRect(RectF(w*.40f,8f,w*.60f,48f),12f,12f,p)
        text(c,"TÚ  $score  -  CPU",w*.415f,36f,20f)

        // Touch controls
        color(Color.argb(75,255,255,255)); c.drawCircle(w*.13f,h*.78f,62f,p)
        color(Color.argb(150,255,255,255)); c.drawCircle(w*.13f+joyX*38f,h*.78f+joyY*38f,25f,p)
        color(Color.argb(100,255,255,255)); c.drawCircle(w*.87f,h*.78f,55f,p)
        text(c,"TIRO",w*.87f-24f,h*.78f+7f,18f)
        text(c,message,w*.40f,h*.96f,17f)
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        val speed = 245f
        if (joyActive) {
            px = (px + joyX*speed*dt).coerceIn(w*.07f,w*.93f)
            py = (py + joyY*speed*dt).coerceIn(h*.14f,h*.86f)
        }
        // Opponent chases the ball, with a gentle speed limit
        val dx = bx-ex; val dy = by-ey; val d = hypot(dx,dy)
        if (d > 2f) {
            ex += dx/d * 115f*dt
            ey += dy/d * 115f*dt
        }
        // Player and opponent nudge the ball
        val pd = hypot(bx-px,by-py)
        if (pd < playerR+ballR && pd > 0f) {
            val nx=(bx-px)/pd; val ny=(by-py)/pd
            bx=px+nx*(playerR+ballR); by=py+ny*(playerR+ballR)
            bvx += nx*45f; bvy += ny*45f
        }
        val ed = hypot(bx-ex,by-ey)
        if (ed < playerR+ballR && ed > 0f) {
            val nx=(bx-ex)/ed; val ny=(by-ey)/ed
            bx=ex+nx*(playerR+ballR); by=ey+ny*(playerR+ballR)
            bvx += nx*55f; bvy += ny*55f
            if (bx < w*.18f) { bvx -= 100f }
        }
        bx += bvx*dt; by += bvy*dt
        val friction = (1f-1.7f*dt).coerceAtLeast(0f)
        bvx *= friction; bvy *= friction
        if (by < h*.12f+ballR || by > h*.88f-ballR) bvy *= -.72f
        if (bx < w*.06f && (by < h*.40f || by > h*.60f)) bvx *= -.75f
        if (bx > w*.94f && (by < h*.40f || by > h*.60f)) bvx *= -.75f
        // Goal on the right
        if (bx > w*.965f && by in (h*.40f..h*.60f)) {
            score++; message="¡GOOOOL!"; resetPositions()
        }
        if (bx < w*.02f && by in (h*.40f..h*.60f)) {
            message="¡El rival marcó!"; resetPositions()
        }
        bx=bx.coerceIn(ballR,w-ballR); by=by.coerceIn(ballR,h-ballR)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x; val y=e.y
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> {
                val idx = e.actionIndex.coerceIn(0,e.pointerCount-1)
                val tx=e.getX(idx); val ty=e.getY(idx)
                if (tx < w*.42f && ty > h*.48f) {
                    joyActive=true
                    val dx=tx-w*.13f; val dy=ty-h*.78f
                    val len=hypot(dx,dy).coerceAtLeast(1f)
                    joyX=(dx/len).coerceIn(-1f,1f); joyY=(dy/len).coerceIn(-1f,1f)
                }
                if (tx > w*.68f && ty > h*.48f) {
                    shootPressed=true
                    val d=hypot(bx-px,by-py)
                    if (d < 105f) {
                        val gx=w-bx; val gy=h*.5f-by
                        val len=hypot(gx,gy).coerceAtLeast(1f)
                        bvx=(gx/len)*640f; bvy=(gy/len)*640f
                        message="¡Buen tiro!"
                    } else message="Acércate al balón"
                }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                joyActive=false; joyX=0f; joyY=0f; shootPressed=false
                invalidate(); return true
            }
        }
        return true
    }
}
